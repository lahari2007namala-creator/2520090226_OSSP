#!/usr/bin/env python3
"""Automated tests for team20 (Python standard library only).

Each test starts ./team20 in a fresh temporary folder, reads its output with
a background thread, sends commands through the named FIFO /tmp/team20_ctl,
and waits for expected output with bounded timeouts (no fixed sleeps for
correctness). Run with:  make test
"""
import os
import re
import shutil
import signal
import subprocess
import tempfile
import threading
import time
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BIN = os.path.join(ROOT, "team20")
FIFO = "/tmp/team20_ctl"
TIMEOUT = 15.0


class Controller:
    """One running instance of ./team20 with a captured output list."""

    def __init__(self, cwd):
        self.cwd = cwd
        self.lines = []
        self.lock = threading.Lock()
        self.proc = subprocess.Popen(
            [BIN], cwd=cwd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, text=True, bufsize=1)
        threading.Thread(target=self._read, daemon=True).start()

    def _read(self):
        for line in self.proc.stdout:
            with self.lock:
                self.lines.append(line.rstrip("\n"))

    def snapshot(self):
        with self.lock:
            return list(self.lines)

    def wait_after(self, start, pred, timeout=TIMEOUT):
        """Return the first line at index >= start matching pred."""
        end = time.time() + timeout
        while time.time() < end:
            for line in self.snapshot()[start:]:
                if pred(line):
                    return line
            time.sleep(0.05)
        raise AssertionError("timeout; output so far:\n" + "\n".join(self.snapshot()))

    def send(self, text):
        # Opening a FIFO for writing blocks until the controller has it open
        # for reading (it keeps its own O_RDWR descriptor open).
        with open(FIFO, "w") as f:
            f.write(text)

    def cmd(self, text):
        """Send one command and return the index where its output starts."""
        start = len(self.snapshot())
        self.send(text + "\n")
        return start

    def child_pids(self):
        """Map child number (1..3) to PID using the READY lines."""
        self.wait_after(0, lambda l: "[child] READY 3 " in l)
        pids = {}
        for line in self.snapshot():
            m = re.search(r"\[child\] READY (\d) (\d+)", line)
            if m:
                pids[int(m.group(1))] = int(m.group(2))
        return pids

    def board(self):
        """Return [w1, w2, w3] from one board command."""
        start = self.cmd("board")
        line = self.wait_after(start, lambda l: l.startswith("BOARD work="))
        m = re.search(r"work=\[(\d+) (\d+) (\d+)\]", line)
        return [int(m.group(i)) for i in (1, 2, 3)]

    def wait_board(self, pred, timeout=TIMEOUT):
        end = time.time() + timeout
        values = None
        while time.time() < end:
            values = self.board()
            if pred(values):
                return values
            time.sleep(0.2)
        raise AssertionError("board never reached expected state; last=%r" % (values,))

    def shutdown_check(self, timeout=TIMEOUT):
        code = self.proc.wait(timeout=timeout)
        return code


def proc_state(pid):
    """Read the one-letter state from /proc/<pid>/stat (None if gone)."""
    try:
        with open("/proc/%d/stat" % pid) as f:
            data = f.read()
    except OSError:
        return None
    return data[data.rindex(")") + 2]


def pid_gone(pid):
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return True
    except PermissionError:
        return False
    # Still exists: it may be a zombie that is not yet reaped.
    return proc_state(pid) == "Z"


def wait_until(pred, timeout=TIMEOUT):
    end = time.time() + timeout
    while time.time() < end:
        if pred():
            return True
        time.sleep(0.05)
    return False


class Team20Tests(unittest.TestCase):

    def setUp(self):
        self.assertTrue(os.path.exists(BIN), "build first: make")
        self.tmp = tempfile.mkdtemp(prefix="team20test_")
        self.c = Controller(self.tmp)
        self.c.wait_after(0, lambda l: "controller ready" in l)
        self.pids = self.c.child_pids()

    def tearDown(self):
        if self.c.proc.poll() is None:
            self.c.proc.kill()
            self.c.proc.wait()
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_startup_three_ready_children_in_one_group(self):
        """Three children are READY and share one process group, not the controller's."""
        self.assertEqual(sorted(self.pids), [1, 2, 3])
        start = self.c.cmd("list")
        self.c.wait_after(start, lambda l: l.startswith("child 3 pid="))
        group_ids = set()
        for n, pid in self.pids.items():
            with open("/proc/%d/stat" % pid) as f:
                pgrp = int(f.read().rsplit(")", 1)[1].split()[2])
            group_ids.add(pgrp)
        self.assertEqual(len(group_ids), 1, "children must share one group")
        controller_pgrp = os.getpgid(self.c.proc.pid)
        self.assertNotIn(controller_pgrp, group_ids)
        self.assertEqual(group_ids, {self.pids[1]})

    def test_stop_and_continue_verified_in_proc(self):
        """SIGSTOP makes the kernel report state T; SIGCONT makes it run again."""
        pid = self.pids[2]
        start = self.c.cmd("stop 2")
        self.c.wait_after(start, lambda l: l.startswith("stop sent to child 2"))
        self.assertTrue(wait_until(lambda: proc_state(pid) == "T"))
        start = self.c.cmd("cont 2")
        self.c.wait_after(start, lambda l: l.startswith("cont sent to child 2"))
        self.assertTrue(wait_until(lambda: proc_state(pid) in ("S", "R")))

    def test_group_stop_and_continue(self):
        """'stop all' and 'cont all' reach every child through the process group."""
        start = self.c.cmd("stop all")
        self.c.wait_after(start, lambda l: l.startswith("stop sent to process group"))
        for pid in self.pids.values():
            self.assertTrue(wait_until(lambda p=pid: proc_state(p) == "T"))
        start = self.c.cmd("cont all")
        self.c.wait_after(start, lambda l: l.startswith("cont sent to process group"))
        for pid in self.pids.values():
            self.assertTrue(wait_until(lambda p=pid: proc_state(p) in ("S", "R")))

    def test_individual_and_group_work_counts(self):
        """Each work signal is counted once; group work hits every child."""
        self.c.cmd("work 1")
        self.assertEqual(self.c.wait_board(lambda v: v[0] == 1), [1, 0, 0])
        self.c.cmd("work all")
        self.assertEqual(self.c.wait_board(lambda v: v == [2, 1, 1]), [2, 1, 1])

    def test_rapid_signals_coalesce_without_fixed_count(self):
        """150 work signals in one burst: the count is >= 1 and <= 150, then stable."""
        self.c.send("work 2\n" * 150)
        last = None
        stable = 0
        end = time.time() + TIMEOUT
        while time.time() < end and stable < 4:
            value = self.c.board()[1]
            stable = stable + 1 if value == last else 0
            last = value
            time.sleep(0.3)
        self.assertEqual(stable, 4, "board did not settle")
        self.assertGreaterEqual(last, 1)
        self.assertLessEqual(last, 150)

    def test_status_and_mem_and_files(self):
        """status gives a reply; mem shows VmRSS and Threads; files shows the FIFO."""
        start = self.c.cmd("status 1")
        self.c.wait_after(start, lambda l: l.startswith("[child] STATUS 1"))
        start = self.c.cmd("mem")
        self.c.wait_after(start, lambda l: l.strip().startswith("VmRSS:"))
        self.c.wait_after(start, lambda l: l.strip().startswith("Threads:"))
        start = self.c.cmd("files")
        self.c.wait_after(start, lambda l: "fifo " + FIFO in l)
        self.c.wait_after(start, lambda l: "team20_events.log" in l and "inode=" in l)

    def test_invalid_malformed_and_overlong_input(self):
        """Bad input gets an error line and the controller keeps running."""
        start = len(self.c.snapshot())
        self.c.send("bogus\nstop 9\nstatus\n" + "x" * 600 + "\n")
        self.c.wait_after(start, lambda l: "unknown command 'bogus'" in l)
        self.c.wait_after(start, lambda l: l.startswith("ERR usage: stop"))
        self.c.wait_after(start, lambda l: "line too long" in l)
        self.assertEqual(len(self.c.board()), 3)

    def test_quit_cleans_up_fifo_children_and_log(self):
        """quit: exit code 0, FIFO removed, no child left, log has shutdown line."""
        self.c.cmd("quit")
        self.assertEqual(self.c.shutdown_check(), 0)
        self.assertFalse(os.path.exists(FIFO))
        for pid in self.pids.values():
            self.assertTrue(pid_gone(pid), "child %d survived" % pid)
        with open(os.path.join(self.tmp, "team20_events.log")) as f:
            self.assertIn("shutdown complete", f.read())

    def test_sigterm_with_a_stopped_worker(self):
        """SIGTERM to the controller resumes stopped workers and reaps them all."""
        start = self.c.cmd("stop all")
        self.c.wait_after(start, lambda l: l.startswith("stop sent to process group"))
        self.c.proc.send_signal(signal.SIGTERM)
        self.assertEqual(self.c.shutdown_check(), 0)
        for pid in self.pids.values():
            self.assertTrue(pid_gone(pid))

    def test_sigint_is_controlled_shutdown(self):
        """Ctrl+C (SIGINT) to the controller also shuts down cleanly."""
        self.c.proc.send_signal(signal.SIGINT)
        self.assertEqual(self.c.shutdown_check(), 0)
        self.assertFalse(os.path.exists(FIFO))

    def test_stdin_eof_shuts_down(self):
        """Closing stdin starts controlled cleanup with exit code 0."""
        self.c.proc.stdin.close()
        self.assertEqual(self.c.shutdown_check(), 0)
        self.assertFalse(os.path.exists(FIFO))

    def test_second_instance_is_refused(self):
        """A second instance reports the conflict and exits with code 1."""
        other = tempfile.mkdtemp(prefix="team20second_")
        try:
            result = subprocess.run([BIN], cwd=other, stdin=subprocess.DEVNULL,
                                    capture_output=True, text=True, timeout=TIMEOUT)
            self.assertEqual(result.returncode, 1)
            self.assertIn("another team20 instance is running", result.stderr)
        finally:
            shutil.rmtree(other, ignore_errors=True)
        self.assertTrue(os.path.exists(FIFO), "first instance's FIFO must be untouched")

    def test_repeated_startup_and_shutdown(self):
        """Two more start/quit cycles leave no FIFO and no zombie children."""
        self.c.cmd("quit")
        self.c.shutdown_check()
        for _ in range(2):
            c = Controller(self.tmp)
            try:
                c.wait_after(0, lambda l: "controller ready" in l)
                pids = c.child_pids()
                c.cmd("quit")
                self.assertEqual(c.shutdown_check(), 0)
                self.assertFalse(os.path.exists(FIFO))
                for pid in pids.values():
                    self.assertTrue(pid_gone(pid))
            finally:
                if c.proc.poll() is None:
                    c.proc.kill()
                    c.proc.wait()


if __name__ == "__main__":
    unittest.main(verbosity=2)
