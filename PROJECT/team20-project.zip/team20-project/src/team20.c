/*
 * team20.c - Linux Signal-Based Process Communication and Control System
 * Course: Operating Systems and Systems Programming (25CS2104E), Team 20
 *
 * Architecture
 *   - One controller (parent) process creates three worker children with fork().
 *   - The children form their own process group (PGID = child 1 PID).
 *   - Control signals: SIGUSR1 (status), SIGUSR2 (work), SIGSTOP / SIGCONT
 *     (stop / continue), SIGTERM (graceful exit).
 *   - Children report events to the parent through an anonymous pipe.
 *   - Commands come from the keyboard (stdin) and from a named FIFO
 *     (/tmp/team20_ctl), so a second terminal can send them.
 *   - A status board is created with mmap(MAP_SHARED | MAP_ANONYMOUS) before
 *     fork(). Its counters are protected by a process-shared semaphore.
 *   - A logger THREAD in the controller takes messages from a bounded
 *     producer-consumer queue (mutex + two condition variables) and writes
 *     timestamped lines to team20_events.log.
 *   - Process, memory and file information is read from /proc.
 *
 * Build:  make      (gcc -std=c11 -Wall -Wextra -Wpedantic -pthread)
 * Run:    ./team20
 */

#define _GNU_SOURCE

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <pthread.h>
#include <semaphore.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#define NUM_CHILDREN 3
#define FIFO_PATH "/tmp/team20_ctl"
#define LOG_PATH "team20_events.log"
#define MSG_LEN 256              /* longest message the logger accepts */
#define QUEUE_CAP 64             /* bounded logger queue capacity */
#define LR_CAP 512               /* longest command or event line */
#define SHUTDOWN_GRACE_MS 3000   /* time children get before SIGKILL */
#define BOARD_WAIT_MS 300        /* how long 'board' waits for the lock */

/* ------------------------------------------------------------------ */
/* Shared status board (lives in shared memory, created before fork)  */
/* ------------------------------------------------------------------ */
typedef struct {
    sem_t lock;                           /* process-shared semaphore (CO4) */
    unsigned long work[NUM_CHILDREN];     /* handled work events per child */
    unsigned long status_replies[NUM_CHILDREN];
    int state[NUM_CHILDREN];              /* 0 starting, 1 ready, 2 exited */
} Board;

/* ------------------------------------------------------------------ */
/* Parent-side state (only the main thread touches these, except the  */
/* logger queue below, which is protected by its own mutex).           */
/* ------------------------------------------------------------------ */
static Board *board = NULL;
static int board_sem_ready = 0;
static pid_t child_pid[NUM_CHILDREN];
static int child_alive[NUM_CHILDREN];
static int child_ready[NUM_CHILDREN];
static pid_t group_id = 0;
static int ev_rd = -1;      /* read end of child->parent event pipe */
static int ev_wr = -1;      /* write end: closed by the parent after fork */
static int ev_open = 1;
static int stdin_open = 1;
static int fifo_fd = -1;
static int fifo_created = 0;
static int shutdown_req = 0;

/* Signal flags: the handlers only set these (async-signal-safe). */
static volatile sig_atomic_t got_int = 0;
static volatile sig_atomic_t got_term = 0;
static volatile sig_atomic_t got_chld = 0;

/* ------------------------------------------------------------------ */
/* Bounded producer-consumer queue for the logger thread (CO4)        */
/* ------------------------------------------------------------------ */
typedef struct {
    char items[QUEUE_CAP][MSG_LEN];
    size_t head, tail, count;
    int closing;
    pthread_mutex_t mu;
    pthread_cond_t not_empty;
    pthread_cond_t not_full;
} LogQueue;

static LogQueue lq = {
    .head = 0, .tail = 0, .count = 0, .closing = 0,
    .mu = PTHREAD_MUTEX_INITIALIZER,
    .not_empty = PTHREAD_COND_INITIALIZER,
    .not_full = PTHREAD_COND_INITIALIZER,
};
static pthread_t logger_tid;
static int logger_running = 0;

/* ------------------------------------------------------------------ */
/* Line reader: frames commands and events that arrive in pieces.     */
/* ------------------------------------------------------------------ */
typedef void (*line_cb)(const char *line, void *ctx);

typedef struct {
    int fd;
    char buf[LR_CAP];
    size_t len;
    int overflow;
} LineReader;

static LineReader lr_fifo, lr_ev, lr_in;

/* Reads once from the fd and calls cb for each complete line.
 * cb(NULL) is called for a line that was too long and was discarded.
 * Returns 0 normally (including EAGAIN), -1 on EOF or a real error. */
static int lr_pump(LineReader *lr, line_cb cb) {
    char tmp[256];
    ssize_t n;
    do {
        n = read(lr->fd, tmp, sizeof tmp);
    } while (n < 0 && errno == EINTR);
    if (n < 0)
        return (errno == EAGAIN || errno == EWOULDBLOCK) ? 0 : -1;
    if (n == 0)
        return -1;
    for (ssize_t i = 0; i < n; i++) {
        char c = tmp[i];
        if (c == '\n') {
            if (lr->overflow) {
                cb(NULL, NULL);
            } else {
                lr->buf[lr->len] = '\0';
                cb(lr->buf, NULL);
            }
            lr->len = 0;
            lr->overflow = 0;
        } else if (c != '\r') {
            if (lr->len < LR_CAP - 1)
                lr->buf[lr->len++] = c;
            else
                lr->overflow = 1;
        }
    }
    return 0;
}

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */
static void fmt_now(char *out, size_t n) {
    struct timespec ts;
    struct tm tmv;
    size_t k;
    clock_gettime(CLOCK_REALTIME, &ts);
    localtime_r(&ts.tv_sec, &tmv);
    k = strftime(out, n, "%Y-%m-%d %H:%M:%S", &tmv);
    snprintf(out + k, n - k, ".%03ld", ts.tv_nsec / 1000000L);
}

static long now_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000L + ts.tv_nsec / 1000000L;
}

/* Put a message in the logger queue (producer side). The main thread
 * blocks here only if 64 messages are already waiting. */
static void lq_put(const char *msg) {
    if (!logger_running)
        return;
    pthread_mutex_lock(&lq.mu);
    while (lq.count == QUEUE_CAP)
        pthread_cond_wait(&lq.not_full, &lq.mu);
    snprintf(lq.items[lq.tail], MSG_LEN, "%s", msg);
    lq.tail = (lq.tail + 1) % QUEUE_CAP;
    lq.count++;
    pthread_cond_signal(&lq.not_empty);
    pthread_mutex_unlock(&lq.mu);
}

/* Print to the terminal and queue the same line for the log file. */
static void say(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
static void say(const char *fmt, ...) {
    char buf[MSG_LEN];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof buf, fmt, ap);
    va_end(ap);
    printf("%s\n", buf);
    lq_put(buf);
}

/* Logger thread: consumer. Blocks signals, writes outside the lock. */
static void *logger_main(void *arg) {
    FILE *f = arg;
    sigset_t all;
    char msg[MSG_LEN], ts[32];

    sigfillset(&all);
    pthread_sigmask(SIG_BLOCK, &all, NULL);

    for (;;) {
        pthread_mutex_lock(&lq.mu);
        while (lq.count == 0 && !lq.closing)
            pthread_cond_wait(&lq.not_empty, &lq.mu);
        if (lq.count == 0) {            /* closing and fully drained */
            pthread_mutex_unlock(&lq.mu);
            break;
        }
        memcpy(msg, lq.items[lq.head], MSG_LEN);
        lq.head = (lq.head + 1) % QUEUE_CAP;
        lq.count--;
        pthread_cond_signal(&lq.not_full);
        pthread_mutex_unlock(&lq.mu);

        fmt_now(ts, sizeof ts);
        fprintf(f, "[%s] %s\n", ts, msg);   /* slow I/O outside the lock */
        fflush(f);
    }
    return NULL;
}

static void log_stop(void) {
    pthread_mutex_lock(&lq.mu);
    lq.closing = 1;
    pthread_cond_broadcast(&lq.not_empty);
    pthread_mutex_unlock(&lq.mu);
}

/* ------------------------------------------------------------------ */
/* Board locking. Children may block (sem_wait). The parent only uses  */
/* timed waits, so a stopped worker that holds the lock cannot freeze  */
/* the controller.                                                     */
/* ------------------------------------------------------------------ */
static void board_lock(Board *b) {
    while (sem_wait(&b->lock) == -1 && errno == EINTR)
        ;
}

static void board_unlock(Board *b) {
    sem_post(&b->lock);
}

static int board_trylock_ms(int ms) {
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    ts.tv_sec += ms / 1000;
    ts.tv_nsec += (long)(ms % 1000) * 1000000L;
    if (ts.tv_nsec >= 1000000000L) {
        ts.tv_sec++;
        ts.tv_nsec -= 1000000000L;
    }
    while (sem_timedwait(&board->lock, &ts) != 0) {
        if (errno != EINTR)
            return -1;
    }
    return 0;
}

/* Writes one event record (under PIPE_BUF, so each write is atomic). */
static void write_record(int fd, const char *fmt, ...) __attribute__((format(printf, 2, 3)));
static void write_record(int fd, const char *fmt, ...) {
    char line[200];
    va_list ap;
    int n;
    const char *p;
    size_t total;

    va_start(ap, fmt);
    n = vsnprintf(line, sizeof line - 1, fmt, ap);
    va_end(ap);
    if (n < 0)
        return;
    if ((size_t)n > sizeof line - 2)
        n = (int)(sizeof line - 2);
    line[n] = '\n';
    p = line;
    total = (size_t)n + 1;
    while (total > 0) {
        ssize_t w = write(fd, p, total);
        if (w < 0) {
            if (errno == EINTR)
                continue;
            return;
        }
        p += w;
        total -= (size_t)w;
    }
}

/* ------------------------------------------------------------------ */
/* CHILD (worker) side                                                 */
/* ------------------------------------------------------------------ */
static volatile sig_atomic_t c_status_pending = 0;
static volatile sig_atomic_t c_work_pending = 0;
static volatile sig_atomic_t c_term_pending = 0;

/* Handler: only sets flags. All real work happens in child_main(). */
static void child_sig(int sig) {
    if (sig == SIGUSR1)
        c_status_pending++;
    else if (sig == SIGUSR2)
        c_work_pending++;
    else if (sig == SIGTERM)
        c_term_pending = 1;
}

/* Runs in the child. Never returns; ends with _exit(). */
static void child_main(int idx, int evrd, int evwr, pid_t pgid) {
    sigset_t empty, blocked;
    struct sigaction sa;
    unsigned long private_work = 0;     /* CO5: private copy per child */

    close(evrd);   /* children never read the event pipe */
    close(0);      /* children never read the keyboard */

    /* Join the worker group. pgid 0 makes child 1 the group leader. */
    if (setpgid(0, pgid) != 0)
        _exit(10);

    sigemptyset(&empty);
    sigprocmask(SIG_SETMASK, &empty, NULL);
    signal(SIGINT, SIG_IGN);     /* Ctrl+C is handled by the controller */
    signal(SIGCHLD, SIG_DFL);

    memset(&sa, 0, sizeof sa);
    sa.sa_handler = child_sig;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sigaction(SIGUSR1, &sa, NULL);
    sigaction(SIGUSR2, &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);

    /* Block the control signals. sigsuspend() below unblocks them and
     * sleeps atomically, so a signal cannot slip in between the check and
     * the sleep (no lost wake-up). */
    sigemptyset(&blocked);
    sigaddset(&blocked, SIGUSR1);
    sigaddset(&blocked, SIGUSR2);
    sigaddset(&blocked, SIGTERM);
    sigprocmask(SIG_BLOCK, &blocked, NULL);

    /* Readiness handshake: the parent sends no signal before READY. */
    board_lock(board);
    board->state[idx] = 1;
    board_unlock(board);
    write_record(evwr, "READY %d %ld", idx + 1, (long)getpid());

    for (;;) {
        sigsuspend(&empty);
        /* sigsuspend restores the blocked set on return, so no handler
         * runs while we process the flags below. Signals that merged while
         * we were busy are reported as fewer events. This is standard
         * POSIX behaviour. */

        if (c_term_pending) {
            board_lock(board);
            board->state[idx] = 2;
            board_unlock(board);
            write_record(evwr, "BYE %d pid=%ld private_work=%lu",
                         idx + 1, (long)getpid(), private_work);
            _exit(0);
        }

        if (c_status_pending) {
            unsigned long n = (unsigned long)c_status_pending;
            unsigned long shared;
            c_status_pending = 0;
            board_lock(board);
            board->status_replies[idx] += n;
            shared = board->work[idx];
            board_unlock(board);
            write_record(evwr, "STATUS %d pid=%ld private_work=%lu shared_work=%lu",
                         idx + 1, (long)getpid(), private_work, shared);
        }

        if (c_work_pending) {
            unsigned long n = (unsigned long)c_work_pending;
            unsigned long shared;
            c_work_pending = 0;
            private_work += n;
            board_lock(board);                 /* critical section (CO4) */
            board->work[idx] += n;
            shared = board->work[idx];
            board_unlock(board);
            write_record(evwr, "WORK %d handled=%lu private_work=%lu shared_work=%lu",
                         idx + 1, n, private_work, shared);
        }
    }
}

/* ------------------------------------------------------------------ */
/* PARENT side: /proc readers                                          */
/* ------------------------------------------------------------------ */
static const char *state_name(char s) {
    switch (s) {
    case 'R': return "running";
    case 'S': return "sleeping";
    case 'D': return "disk-sleep";
    case 'T': return "stopped";
    case 't': return "tracing-stop";
    case 'Z': return "zombie";
    case 'X': return "dead";
    default:  return "other";
    }
}

/* Reads /proc/<pid>/stat. The name field may contain spaces, so parse
 * after the last ')'. */
static int proc_stat(pid_t pid, char *state, int *ppid, int *pgid) {
    char path[64], buf[512];
    FILE *f;
    size_t n;
    char *rp;
    snprintf(path, sizeof path, "/proc/%ld/stat", (long)pid);
    f = fopen(path, "r");
    if (!f)
        return -1;
    n = fread(buf, 1, sizeof buf - 1, f);
    fclose(f);
    buf[n] = '\0';
    rp = strrchr(buf, ')');
    if (!rp)
        return -1;
    return sscanf(rp + 2, "%c %d %d", state, ppid, pgid) == 3 ? 0 : -1;
}

static void show_proc_mem(const char *label, pid_t pid) {
    char path[64], line[256];
    FILE *f;
    snprintf(path, sizeof path, "/proc/%ld/status", (long)pid);
    f = fopen(path, "r");
    if (!f) {
        say("%s pid=%ld: %s not readable", label, (long)pid, path);
        return;
    }
    say("%s pid=%ld (from %s):", label, (long)pid, path);
    while (fgets(line, sizeof line, f)) {
        if (!strncmp(line, "VmSize:", 7) || !strncmp(line, "VmRSS:", 6) ||
            !strncmp(line, "Threads:", 8)) {
            line[strcspn(line, "\n")] = '\0';
            say("    %s", line);
        }
    }
    fclose(f);
}

static const char *board_state_name(int s) {
    switch (s) {
    case 0: return "starting";
    case 1: return "ready";
    case 2: return "exited";
    default: return "?";
    }
}

/* ------------------------------------------------------------------ */
/* PARENT commands                                                     */
/* ------------------------------------------------------------------ */
static void print_help(void) {
    say("Commands (keyboard or FIFO %s):", FIFO_PATH);
    say("  status <1|2|3|all>  SIGUSR1: child reports its status");
    say("  work   <1|2|3|all>  SIGUSR2: child handles one work event");
    say("  stop   <1|2|3|all>  SIGSTOP: pause child (group with 'all')");
    say("  cont   <1|2|3|all>  SIGCONT: resume child");
    say("  list                child PIDs, group, kernel state from /proc");
    say("  board               shared memory status board (semaphore-locked)");
    say("  mem                 VmSize, VmRSS, Threads from /proc");
    say("  files               open descriptors and log-file metadata");
    say("  help                this text");
    say("  quit                graceful shutdown (also Ctrl+C, SIGTERM, EOF)");
}

static void cmd_list(void) {
    say("controller pid=%ld pgid=%ld (not in the worker group)",
        (long)getpid(), (long)getpgrp());
    for (int i = 0; i < NUM_CHILDREN; i++) {
        char st = '?';
        int ppid = 0, pgid = 0;
        if (!child_alive[i]) {
            say("child %d: exited and reaped", i + 1);
            continue;
        }
        if (proc_stat(child_pid[i], &st, &ppid, &pgid) != 0) {
            say("child %d pid=%ld: /proc entry not readable", i + 1, (long)child_pid[i]);
            continue;
        }
        say("child %d pid=%ld ppid=%d pgid=%d state=%c (%s) ready=%s",
            i + 1, (long)child_pid[i], ppid, pgid, st, state_name(st),
            child_ready[i] ? "yes" : "no");
    }
}

static void cmd_board(void) {
    unsigned long w[NUM_CHILDREN], total = 0;
    int st[NUM_CHILDREN];
    if (board_trylock_ms(BOARD_WAIT_MS) != 0) {
        say("BOARD busy: lock not acquired in %d ms (a stopped worker may hold it). "
            "Try 'cont all'.", BOARD_WAIT_MS);
        return;
    }
    for (int i = 0; i < NUM_CHILDREN; i++) {
        w[i] = board->work[i];
        st[i] = board->state[i];
        total += w[i];
    }
    sem_post(&board->lock);
    say("BOARD work=[%lu %lu %lu] total=%lu states=[%s %s %s]",
        w[0], w[1], w[2], total,
        board_state_name(st[0]), board_state_name(st[1]), board_state_name(st[2]));
}

static void cmd_mem(void) {
    show_proc_mem("controller", getpid());
    for (int i = 0; i < NUM_CHILDREN; i++) {
        if (child_alive[i])
            show_proc_mem("child", child_pid[i]);
    }
}

static void cmd_files(void) {
    struct stat st;
    DIR *d;
    struct dirent *e;

    say("open descriptors of controller (/proc/self/fd):");
    d = opendir("/proc/self/fd");
    if (d) {
        while ((e = readdir(d)) != NULL) {
            char link[300], target[256];
            ssize_t n;
            if (e->d_name[0] == '.')
                continue;
            snprintf(link, sizeof link, "/proc/self/fd/%s", e->d_name);
            n = readlink(link, target, sizeof target - 1);
            if (n < 0)
                continue;
            target[n] = '\0';
            say("    fd %-3s -> %s", e->d_name, target);
        }
        closedir(d);
    }
    if (stat(LOG_PATH, &st) == 0)
        say("log %s: inode=%lu size=%lld bytes mode=%o links=%lu",
            LOG_PATH, (unsigned long)st.st_ino, (long long)st.st_size,
            (unsigned)(st.st_mode & 07777), (unsigned long)st.st_nlink);
    else
        say("log %s: not found", LOG_PATH);
    if (stat(FIFO_PATH, &st) == 0)
        say("fifo %s: inode=%lu mode=%o (FIFO)", FIFO_PATH,
            (unsigned long)st.st_ino, (unsigned)(st.st_mode & 07777));
}

static int signal_for_verb(const char *v) {
    if (!strcmp(v, "status")) return SIGUSR1;
    if (!strcmp(v, "work"))   return SIGUSR2;
    if (!strcmp(v, "stop"))   return SIGSTOP;
    if (!strcmp(v, "cont"))   return SIGCONT;
    return 0;
}

static int alive_count(void) {
    int n = 0;
    for (int i = 0; i < NUM_CHILDREN; i++)
        if (child_alive[i]) n++;
    return n;
}

static void cmd_signal(const char *verb, int sig, const char *arg) {
    if (!strcmp(arg, "all")) {
        for (int i = 0; i < NUM_CHILDREN; i++) {
            if (!child_alive[i]) {
                say("ERR child %d is not running; group signal not sent", i + 1);
                return;
            }
            if (!child_ready[i]) {
                say("ERR child %d is not ready yet; group signal not sent", i + 1);
                return;
            }
        }
        /* Never signal our own group (safety check). */
        if (group_id <= 1 || group_id == getpgrp()) {
            say("ERR unsafe group id %ld; refusing", (long)group_id);
            return;
        }
        if (kill(-group_id, sig) != 0)
            say("ERR kill(-%ld, %s): %s", (long)group_id, verb, strerror(errno));
        else
            say("%s sent to process group %ld (children 1, 2, 3)", verb, (long)group_id);
        return;
    }
    if (!(arg[0] >= '1' && arg[0] <= '3' && arg[1] == '\0')) {
        say("ERR usage: %s <1|2|3|all>", verb);
        return;
    }
    {
        int i = arg[0] - '1';
        if (!child_alive[i]) {
            say("ERR child %d is not running (already exited)", i + 1);
            return;
        }
        if (!child_ready[i]) {
            say("ERR child %d is not ready yet", i + 1);
            return;
        }
        if (kill(child_pid[i], sig) != 0)
            say("ERR kill(pid %ld, %s): %s", (long)child_pid[i], verb, strerror(errno));
        else
            say("%s sent to child %d (pid %ld)", verb, i + 1, (long)child_pid[i]);
    }
}

/* Dispatch one complete command line. Used by both keyboard and FIFO. */
static void handle_command(const char *line, void *unused) {
    char verb[32] = "", arg[64] = "";
    int sig;
    (void)unused;

    if (line == NULL) {
        say("ERR line too long (limit %d characters); ignored", LR_CAP - 1);
        return;
    }
    if (sscanf(line, "%31s %63s", verb, arg) < 1)
        return;                       /* blank line */

    sig = signal_for_verb(verb);
    if (!strcmp(verb, "help"))        print_help();
    else if (!strcmp(verb, "list"))   cmd_list();
    else if (!strcmp(verb, "board"))  cmd_board();
    else if (!strcmp(verb, "mem"))    cmd_mem();
    else if (!strcmp(verb, "files"))  cmd_files();
    else if (!strcmp(verb, "quit")) {
        say("quit requested");
        shutdown_req = 1;
    } else if (sig != 0) {
        cmd_signal(verb, sig, arg);
    } else {
        say("ERR unknown command '%s' (type help)", verb);
    }
}

/* Handle a line from a child: READY marks the child ready. */
static void handle_child_line(const char *line, void *unused) {
    int idx;
    long pid;
    (void)unused;
    if (line == NULL) {
        say("ERR child event too long; ignored");
        return;
    }
    if (sscanf(line, "READY %d %ld", &idx, &pid) == 2 &&
        idx >= 1 && idx <= NUM_CHILDREN)
        child_ready[idx - 1] = 1;
    say("[child] %s", line);
}

/* Parent signal handler: flags only. */
static void parent_sig(int sig) {
    if (sig == SIGINT)
        got_int = 1;
    else if (sig == SIGTERM)
        got_term = 1;
    else if (sig == SIGCHLD)
        got_chld = 1;
}

/* Reap any child that changed state. waitpid() on our own PIDs only. */
static void reap_children(void) {
    for (int i = 0; i < NUM_CHILDREN; i++) {
        int status = 0;
        pid_t r;
        if (!child_alive[i])
            continue;
        r = waitpid(child_pid[i], &status, WNOHANG);
        if (r == 0)
            continue;
        if (r < 0) {
            if (errno == EINTR)
                continue;
            say("waitpid(child %d) failed: %s", i + 1, strerror(errno));
            child_alive[i] = 0;
            continue;
        }
        child_alive[i] = 0;
        child_ready[i] = 0;
        if (WIFEXITED(status))
            say("child %d (pid %ld) exited with status %d; reaped",
                i + 1, (long)child_pid[i], WEXITSTATUS(status));
        else if (WIFSIGNALED(status))
            say("child %d (pid %ld) killed by signal %d; reaped",
                i + 1, (long)child_pid[i], WTERMSIG(status));
    }
}

/* Read any pending child events, waiting at most ms milliseconds. */
static void drain_events(int ms) {
    struct pollfd p;
    if (!ev_open) {
        struct timespec ts = { 0, (long)ms * 1000000L };
        nanosleep(&ts, NULL);   /* no pipe to wait on: avoid busy loop */
        return;
    }
    p.fd = ev_rd;
    p.events = POLLIN;
    p.revents = 0;
    if (poll(&p, 1, ms) > 0 && (p.revents & (POLLIN | POLLHUP | POLLERR))) {
        if (lr_pump(&lr_ev, handle_child_line) < 0) {
            ev_open = 0;
        }
    }
}

/* Controlled shutdown: resume, terminate, drain, reap, then escalate. */
static void shutdown_children(void) {
    long deadline;
    say("shutdown: resuming stopped workers and sending SIGTERM");
    for (int i = 0; i < NUM_CHILDREN; i++) {
        if (child_alive[i]) {
            kill(child_pid[i], SIGCONT);   /* a stopped child cannot act on SIGTERM */
            kill(child_pid[i], SIGTERM);
        }
    }
    deadline = now_ms() + SHUTDOWN_GRACE_MS;
    while (alive_count() > 0 && now_ms() < deadline) {
        drain_events(50);
        reap_children();
    }
    for (int i = 0; i < NUM_CHILDREN; i++) {
        if (child_alive[i]) {
            int status;
            say("child %d (pid %ld) did not exit in time; sending SIGKILL",
                i + 1, (long)child_pid[i]);
            kill(child_pid[i], SIGKILL);
            waitpid(child_pid[i], &status, 0);
            child_alive[i] = 0;
        }
    }
    /* Read remaining event lines until the pipe is empty. */
    while (ev_open) {
        struct pollfd p;
        p.fd = ev_rd;
        p.events = POLLIN;
        p.revents = 0;
        if (poll(&p, 1, 0) <= 0)
            break;
        if (lr_pump(&lr_ev, handle_child_line) < 0)
            ev_open = 0;
    }
}

/* Stop children that were started before a startup failure. */
static void kill_started_children(int started) {
    for (int i = 0; i < started; i++) {
        if (child_alive[i]) {
            int status;
            kill(child_pid[i], SIGKILL);
            waitpid(child_pid[i], &status, 0);
            child_alive[i] = 0;
        }
    }
}

/* Remove only resources created by this instance. */
static void teardown(void) {
    if (fifo_fd >= 0) { close(fifo_fd); fifo_fd = -1; }
    if (ev_rd >= 0)   { close(ev_rd);   ev_rd = -1; }
    if (ev_wr >= 0)   { close(ev_wr);   ev_wr = -1; }
    if (board_sem_ready) { sem_destroy(&board->lock); board_sem_ready = 0; }
    if (board) { munmap(board, sizeof *board); board = NULL; }
    if (fifo_created) { unlink(FIFO_PATH); fifo_created = 0; }
}

int main(void) {
    struct stat st;
    struct sigaction sa;
    sigset_t blk, none;
    int evp[2];
    FILE *logf = NULL;
    pid_t pgid = 0;
    void *board_map;

    setvbuf(stdout, NULL, _IOLBF, 0);
    signal(SIGPIPE, SIG_IGN);

    /* 1. Instance check. A live FIFO reader means another instance runs. */
    if (lstat(FIFO_PATH, &st) == 0) {
        int t;
        if (!S_ISFIFO(st.st_mode)) {
            fprintf(stderr, "ERROR: %s exists and is not a FIFO. Remove it manually.\n",
                    FIFO_PATH);
            return 1;
        }
        t = open(FIFO_PATH, O_WRONLY | O_NONBLOCK);
        if (t >= 0) {
            close(t);
            fprintf(stderr, "ERROR: another team20 instance is running "
                            "(FIFO %s has a reader).\n", FIFO_PATH);
            return 1;
        }
        if (errno != ENXIO) {
            perror("open existing FIFO");
            return 1;
        }
        unlink(FIFO_PATH);          /* stale FIFO from a crashed run */
        printf("note: removed stale FIFO left by an earlier run\n");
    }
    if (mkfifo(FIFO_PATH, 0600) != 0) {
        perror("mkfifo");
        return 1;
    }
    fifo_created = 1;

    /* 2. Anonymous event pipe (children -> parent). */
    if (pipe(evp) != 0) {
        perror("pipe");
        teardown();
        return 1;
    }
    ev_rd = evp[0];
    ev_wr = evp[1];
    fcntl(ev_rd, F_SETFL, fcntl(ev_rd, F_GETFL) | O_NONBLOCK);

    /* 3. Shared status board, mapped BEFORE fork() so every child has it. */
    board_map = mmap(NULL, sizeof(Board), PROT_READ | PROT_WRITE,
                     MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    if (board_map == MAP_FAILED) {
        perror("mmap");
        teardown();
        return 1;
    }
    board = board_map;
    memset(board, 0, sizeof *board);
    if (sem_init(&board->lock, 1 /* process-shared */, 1) != 0) {
        perror("sem_init");
        teardown();
        return 1;
    }
    board_sem_ready = 1;

    /* 4. Fork all three children BEFORE the logger thread exists. */
    fflush(stdout);
    for (int i = 0; i < NUM_CHILDREN; i++) {
        pid_t pid = fork();
        if (pid < 0) {
            perror("fork");
            kill_started_children(i);
            teardown();
            return 1;
        }
        if (pid == 0) {
            child_main(i, ev_rd, ev_wr, pgid);
            _exit(0);   /* not reached */
        }
        if (i == 0)
            pgid = pid;          /* child 1 leads the worker group */
        child_pid[i] = pid;
        child_alive[i] = 1;
        setpgid(pid, pgid);      /* parent-side join avoids a race */
    }
    group_id = pgid;
    close(ev_wr);
    ev_wr = -1;

    /* 5. Open the FIFO and the log file AFTER fork (no fd inheritance). */
    fifo_fd = open(FIFO_PATH, O_RDWR | O_NONBLOCK);  /* RDWR: never sees EOF */
    if (fifo_fd < 0) {
        perror("open FIFO");
        shutdown_children();
        teardown();
        return 1;
    }
    logf = fopen(LOG_PATH, "a");
    if (!logf) {
        perror("open log file");
        shutdown_children();
        teardown();
        return 1;
    }

    /* 6. Logger thread. Check the pthread return code. */
    {
        int rc = pthread_create(&logger_tid, NULL, logger_main, logf);
        if (rc != 0) {
            fprintf(stderr, "pthread_create: %s\n", strerror(rc));
            shutdown_children();
            fclose(logf);
            teardown();
            return 1;
        }
        logger_running = 1;
    }

    /* 7. Signal handling: flags only. Block the three async signals so they
     *    are delivered only inside ppoll(), which unblocks them atomically. */
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = parent_sig;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sigaction(SIGINT, &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);
    sigaction(SIGCHLD, &sa, NULL);
    sigemptyset(&blk);
    sigaddset(&blk, SIGINT);
    sigaddset(&blk, SIGTERM);
    sigaddset(&blk, SIGCHLD);
    sigprocmask(SIG_BLOCK, &blk, NULL);
    sigemptyset(&none);

    lr_fifo.fd = fifo_fd;
    lr_ev.fd = ev_rd;
    lr_in.fd = 0;

    say("controller ready: pid=%ld, worker group=%ld, FIFO=%s, log=%s",
        (long)getpid(), (long)group_id, FIFO_PATH, LOG_PATH);
    say("type 'help' for commands; from another terminal: echo 'list' > %s", FIFO_PATH);

    /* 8. Main loop: one ppoll() over stdin, the event pipe and the FIFO. */
    while (!shutdown_req) {
        struct pollfd pf[3];
        nfds_t n = 0;
        int i_fifo, i_ev = -1, i_in = -1;
        struct timespec ts = { 0, 200000000L };
        int rc;

        pf[n].fd = fifo_fd; pf[n].events = POLLIN; pf[n].revents = 0;
        i_fifo = (int)n++;
        if (ev_open) {
            pf[n].fd = ev_rd; pf[n].events = POLLIN; pf[n].revents = 0;
            i_ev = (int)n++;
        }
        if (stdin_open) {
            pf[n].fd = 0; pf[n].events = POLLIN; pf[n].revents = 0;
            i_in = (int)n++;
        }

        rc = ppoll(pf, n, &ts, &none);
        if (rc < 0 && errno != EINTR) {
            perror("ppoll");
            break;
        }

        if (got_int || got_term) {
            say("signal received: starting controlled shutdown");
            break;
        }
        if (got_chld) {
            got_chld = 0;
            reap_children();
        }
        if (alive_count() == 0) {
            say("all workers have exited; starting shutdown");
            break;
        }
        if (rc <= 0)
            continue;

        if (pf[i_fifo].revents) {
            if (lr_pump(&lr_fifo, handle_command) < 0) {
                say("FIFO read error; starting shutdown");
                break;
            }
        }
        if (i_ev >= 0 && pf[i_ev].revents) {
            if (lr_pump(&lr_ev, handle_child_line) < 0) {
                ev_open = 0;
                say("event pipe closed (all workers have exited)");
            }
        }
        if (i_in >= 0 && pf[i_in].revents) {
            if (lr_pump(&lr_in, handle_command) < 0) {
                stdin_open = 0;
                say("stdin closed (EOF): starting shutdown");
                break;
            }
        }
    }

    /* 9. Controlled shutdown, then drain and join the logger. */
    shutdown_children();
    say("shutdown complete: all workers reaped");
    log_stop();
    pthread_join(logger_tid, NULL);
    logger_running = 0;
    fflush(logf);
    fclose(logf);
    teardown();
    printf("team20 exited cleanly\n");
    return 0;
}
