# Team 20 - Linux Signal-Based Process Communication and Control System

Course: Operating Systems and Systems Programming (25CS2104E), Section 13, Team 20.
Platform: Ubuntu Linux or Ubuntu on WSL2. Language: C11 with POSIX APIs. Tests: Python 3 standard library.

## 1. Setup (Ubuntu / WSL2)

```bash
sudo apt update
sudo apt install -y build-essential python3
```

## 2. Folder structure

```
team20-project/
├── Makefile              build, run, test, clean
├── README.md             this file
├── src/team20.c          the whole program (controller + workers)
└── tests/test_team20.py  automated tests (unittest)
```

## 3. Build, run, test

Open an Ubuntu terminal and go into the project folder:

```bash
cd ~/team20-project
make            # builds ./team20 with -std=c11 -Wall -Wextra -Wpedantic -pthread
make run        # starts the controller in this terminal (Terminal 1)
make test       # runs the 13 automated tests
make clean      # removes ./team20, team20_events.log, __pycache__
```

## 4. Using a second terminal (FIFO commands)

Start `make run` in Terminal 1. Open a second Ubuntu terminal (Terminal 2) and type:

```bash
echo "list" > /tmp/team20_ctl
echo "work all" > /tmp/team20_ctl
echo "quit" > /tmp/team20_ctl
```

Terminal 1 prints the result. The same commands can also be typed directly in Terminal 1.

## 5. Commands

| Command | Signal / action |
|---|---|
| `help` | list commands |
| `list` | PIDs, PPID, PGID and kernel state (`S`, `T`, ...) from `/proc/<pid>/stat` |
| `status <1\|2\|3\|all>` | SIGUSR1: child replies with a STATUS line |
| `work <1\|2\|3\|all>` | SIGUSR2: child handles one work event (counted on the board) |
| `stop <1\|2\|3\|all>` | SIGSTOP: pause (`all` uses `kill(-pgid, ...)`) |
| `cont <1\|2\|3\|all>` | SIGCONT: resume |
| `board` | snapshot of the shared status board (semaphore-locked, bounded wait) |
| `mem` | VmSize, VmRSS, Threads from `/proc/<pid>/status` |
| `files` | open descriptors from `/proc/self/fd` and log/FIFO `stat()` data |
| `quit` | controlled shutdown |

Ctrl+C, `kill -TERM <controller pid>` and closing stdin (Ctrl+D) also start controlled shutdown.

## 6. Architecture

- One controller (parent) calls `fork()` three times. Child 1 starts the process group
  (`setpgid(0,0)`); children 2 and 3 join it. The controller is in a different group.
- Each child installs handlers with `sigaction()` and sends `READY` through the pipe.
  The controller sends no signal before `READY` (readiness handshake).
- Children wait in `sigsuspend()` after blocking their control signals. This avoids lost wake-ups.
- Child-to-parent events use an anonymous pipe (`pipe()`), one line per write (under `PIPE_BUF`).
- Commands come from stdin and from the named FIFO `/tmp/team20_ctl` (`mkfifo`, mode 0600).
  The controller opens it `O_RDWR|O_NONBLOCK`, so it never sees EOF and never busy-loops.
- The status board is `mmap(MAP_SHARED|MAP_ANONYMOUS)` created before `fork()`. A process-shared
  `sem_t` guards it. The controller uses `sem_timedwait`, so a stopped worker holding the lock
  cannot freeze it.
- A logger thread (created after the forks) takes messages from a bounded queue of 64 entries
  protected by one mutex and two condition variables. It writes outside the lock.
  `team20_events.log` is opened with `O_APPEND` (through `fopen "a"`).
- Shutdown: resume (`SIGCONT`), terminate (`SIGTERM`), drain the pipe, reap with `waitpid`,
  escalate to `SIGKILL` after 3 s, then join the logger, destroy the semaphore, unmap the board
  and unlink the FIFO that this instance created.

## 7. Troubleshooting

| Message | Meaning and fix |
|---|---|
| `another team20 instance is running` | A controller already holds the FIFO. Quit it first (`quit`). |
| `removed stale FIFO left by an earlier run` | Normal after a crash. The old FIFO is replaced. |
| `... exists and is not a FIFO. Remove it manually.` | Something else is at `/tmp/team20_ctl`. Check it with `ls -l /tmp/team20_ctl`, then delete it yourself. |
| `BOARD busy` | A stopped worker holds the lock. Run `cont all`, then `board` again. |
| Controller exits at once when run from a script | stdin is closed, which counts as EOF. Run it from a terminal, or keep stdin open. |
| `make: gcc: not found` | Run `sudo apt install -y build-essential`. |

## 8. Known limitations

- Standard signals can merge. Sending 150 `work` signals gives fewer handled events; the board
  counts only the events the children actually handled.
- Workers are forked copies of the same program (no `exec()`), so this is not a demo of separate
  programs.
- The FIFO and the log file are fixed paths, so only one controller runs at a time.
- Stop/continue controls whether a process may run. It does not implement a CPU scheduling policy.

## 9. Verification status

The program and tests were compiled and run on Linux (Ubuntu-style environment, GCC):

- Build with `-std=c11 -Wall -Wextra -Wpedantic -pthread`: no warnings after one fix.
- `make test`: 13 tests, all passing (startup and process groups, stop/continue with `/proc`,
  group stop/continue, individual and group work counts, 150-signal coalescing, status/mem/files,
  invalid and overlong input, quit, SIGTERM with a stopped worker, SIGINT, stdin EOF,
  second-instance refusal, repeated startup/shutdown).
- Not yet verified: a live run inside WSL2 on Windows, and any run with a real Ubuntu desktop
  terminal (the tests use the same commands).

## 10. CO mapping (what this project actually demonstrates)

| CO | Concept demonstrated | Main functions in `src/team20.c` |
|---|---|---|
| CO1 | system calls, error checks, user vs kernel | `fork`, `kill`, `waitpid`, `pipe`, `read`/`write`, `sigaction`, `/proc` reads |
| CO2 | process creation, groups, stop/continue, reaping | `child_main`, `cmd_signal`, `reap_children`, `shutdown_children`, `cmd_list` |
| CO3 | signals, pipe, FIFO, masks, group signals | `child_sig`, `parent_sig`, `sigsuspend`, `ppoll`, `handle_command` |
| CO4 | threads, mutex, condvars, semaphore | `logger_main`, `lq_put`, `log_stop`, `board_lock`, `board_trylock_ms` |
| CO5 | mmap shared memory, private vs shared data, /proc memory | `main` (mmap), `Board`, `private_work`, `cmd_mem` |
| CO6 | fds, open flags, log file, stat, FIFO, unlink | `cmd_files`, `mkfifo`, `unlink` in `teardown`, `fopen "a"` |

Syllabus confirmation: the official CO text was not attached. The mapping above follows the
review decks. Please check it against the official syllabus before submission.
