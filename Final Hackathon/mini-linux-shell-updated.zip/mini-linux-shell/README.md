# Mini Linux Shell with Background Job Management

A C shell with real Linux job control and a Python/Tkinter desktop UI. The C
program also works independently in a normal terminal. No Python packages,
web server, database, or internet connection are required after installing
the system dependencies.

## Quick start on Ubuntu

Run these commands in an Ubuntu terminal, from the extracted project folder:

```bash
sudo apt update
sudo apt install -y build-essential python3 python3-tk
make
python3 gui.py
```

After the initial setup, you can also start the application with:

```bash
bash run.sh
```

The window contains a command entry, live terminal output, current directory,
real child PIDs/states, counters, and job controls. Python 3.10+ is recommended.
The C program targets Linux with POSIX job-control support.

### Windows / VS Code

Use Ubuntu inside WSL, not Windows CMD or a native Windows C compiler. If WSL
is not installed, run the following in an Administrator PowerShell, then
follow Windows' installation/restart prompts:

```powershell
wsl --install -d Ubuntu
```

Open Ubuntu, complete its initial username/password setup, and run the Ubuntu
commands above. For the desktop UI you need a working Linux graphical session
(WSLg or a configured Linux display). A minimal/headless WSL session can run
the command-line shell instead. On a college Ubuntu desktop, no WSL is needed.

If the ZIP is in your Windows Downloads folder, open that folder in Windows,
extract it, and locate the `mini-linux-shell` folder. In Ubuntu its path is
usually `/mnt/c/Users/YOUR_WINDOWS_USERNAME/Downloads/mini-linux-shell`.
Replace the username and path with your actual location before using `cd`.

## Build and launch

```bash
# In the project folder:
make                 # Compile C source with warnings enabled
make ui              # Build and open the desktop UI
make run             # Build and open the command-line shell
make test            # Run 10 real-process integration tests
```

Without make:

```bash
gcc -std=c11 -Wall -Wextra -Wpedantic -O2 mini_shell.c -o mini_shell
python3 gui.py
```

To run the C shell without the desktop UI:

```bash
./mini_shell
```

## Commands to try inside the application

```text
help
pwd
ls
echo "Hello from our mini shell"
sleep 30 &
jobs
```

Select the sleep job in the jobs panel. Choose **Foreground**, then use
**Stop ^Z**. The job changes to Stopped. Choose **Resume** to continue it in
the background, or **Terminate** to send SIGTERM.

The equivalent typed commands are:

```text
fg %1
bg %1
kill %1
kill -STOP %1
kill -KILL %1
```

Replace `%1` with the actual ID shown by `jobs`. Every external command gets
a new job ID, including foreground commands, so the sleep job may not be `%1`.

`kill` is a shell built-in that accepts tracked job IDs only. It does not
accept an arbitrary operating-system PID. Supported signals: TERM (default),
INT, KILL (or 9), STOP, CONT; the SIG prefix is also accepted.

## Desktop UI controls

| Control | Behaviour |
| --- | --- |
| Run / Send or Enter | Submit a shell command, or input to a foreground program |
| Up / Down in entry | Navigate the session's input history |
| Interrupt / Ctrl+C in entry | Send terminal interrupt to the foreground process group |
| Stop / Ctrl+Z in entry | Stop the foreground process group |
| End input / Ctrl+D in entry | End foreground program input; at an empty shell prompt, exit |
| Foreground | Give the selected active job terminal ownership |
| Resume | Continue a selected stopped job in the background |
| Terminate | Send SIGTERM to the selected active job |
| Clear view / Ctrl+L | Clear displayed output; running jobs continue |
| Close window | Ask the C shell to clean up its tracked jobs before closing |

The GUI disables shell-command buttons while a foreground program owns the
terminal. The input entry remains available for programs such as `cat`.
Use the Interrupt and Stop buttons to regain the shell prompt.

The jobs panel keeps up to 32 recent jobs, including completed foreground
commands. The `jobs` built-in lists background/stopped jobs and completed
background jobs. Completed slots are reused when the table fills. The counters
describe the current table, not lifetime totals. “Running” means the process
has not stopped or exited; it may currently be sleeping or waiting for CPU.

## Architecture

1. Tkinter collects input and displays output.
2. `ui_backend.py` starts the C shell in a controlling pseudo-terminal (PTY).
3. The C shell parses arguments and handles built-ins.
4. `fork()` creates a child; `execvp()` loads the external program.
5. `setpgid()` places the child in its own process group.
6. `tcsetpgrp()` transfers terminal ownership for a foreground job.
7. `SIGCHLD` wakes the event loop through a self-pipe. `waitpid()` reaps children
   and records completion, stopping and continuation.
8. A private, inherited Unix datagram socket carries C job-table snapshots to
   the UI. This does not expose a network service or execute commands in Python.

The forked child waits on a pipe until the parent has established its process
group and, for a foreground job, transferred terminal ownership. This avoids
an early terminal read stopping a newly launched foreground child.

All command execution and process management are implemented in C. Linux
performs the actual CPU scheduling. The GUI is a presentation/control layer.

## Supported syntax and limits

- One external program per job, with arguments and optional final `&`.
- Single/double quoted arguments and backslash escaping.
- Built-ins: `help`, `pwd`, `cd`, `jobs`, `fg`, `bg`, `kill`, `exit`.
- Up to 32 active jobs; a 4095-byte C input limit; up to 127 arguments.
- The desktop input uses a smaller 3000-byte submission limit.
- Pipes, redirection, command chaining, environment/tilde/wildcard expansion,
  command substitution and shell scripts are not implemented.
- The desktop output is a line-oriented text view, not a complete terminal
  emulator. Use the CLI for full-screen programs; avoid `vim`, `top`, `less`
  and cursor-addressing applications in the desktop view.
- Jobs contain one directly launched external program. Programs that daemonize,
  escape their group, or create independently surviving descendants are outside
  the cleanup guarantee. Use simple controlled commands for demonstrations.
- `exit`, GUI close, SIGHUP and SIGTERM clean up active tracked groups: HUP and
  CONT, a bounded grace period, then KILL if necessary, followed by reaping.
- Like other programs, the shell cannot run cleanup after SIGKILL or a power loss.

## Files

| File | Purpose |
| --- | --- |
| `mini_shell.c` | C command parser, built-ins and Linux job-control implementation |
| `gui.py` | Desktop window and controls |
| `ui_backend.py` | PTY and status-channel transport |
| `Makefile` | Build/run/test commands |
| `run.sh` | Build and launch from any working directory |
| `tests/test_shell.py` | Integration tests using real processes and a PTY |
| `TESTING.md` | Test scenarios and validation record |
| `REPORT.md` | Technical report and explanation |
| `DEMO.md` | Live demonstration and team preparation |

## Troubleshooting

**`gcc: command not found` / `make: command not found`:** install `build-essential`.

**`No module named tkinter`:** use Ubuntu's `python3` and install `python3-tk`.
If a virtual environment or custom Python is active, try `/usr/bin/python3 gui.py`.

**`no display name and no $DISPLAY` / `couldn't connect to display`:** the
environment has no usable graphical desktop. Run `./mini_shell` for now, or
use Ubuntu desktop / a WSLg session for the UI. Do not guess a DISPLAY value.

**Background `cat` becomes Stopped:** expected behaviour. A background process
reading the controlling terminal receives SIGTTIN. Use `fg %ID` before typing
its input. End input with Ctrl+D.

**Cannot close the app with `exit` while a command is running:** first interrupt
or stop the foreground command. Text typed at that point goes to that program.
The window's close button also requests cleanup directly.

## GitHub upload

Run these in the regular Ubuntu terminal, outside the mini shell:

```bash
git init
git add .
git commit -m "Implement C mini shell with desktop job management UI"
```

Create an empty GitHub repository in your own account, then run:

```bash
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/mini-linux-shell.git
git push -u origin main
```

Replace `YOUR_USERNAME` and configure Git authentication as required. A remote
repository is not created automatically by this download. Review the code and
record the results from your own environment.

## References

- GNU C Library: https://www.gnu.org/software/libc/manual/html_node/Implementing-a-Shell.html
- Python PTY documentation: https://docs.python.org/3/library/pty.html
- Python Tkinter documentation: https://docs.python.org/3/library/tkinter.html
- Microsoft WSL installation: https://learn.microsoft.com/windows/wsl/install
- Microsoft WSL GUI apps: https://learn.microsoft.com/windows/wsl/tutorials/gui-apps
