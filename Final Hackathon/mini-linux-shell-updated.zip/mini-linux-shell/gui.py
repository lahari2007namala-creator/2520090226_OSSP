#!/usr/bin/env python3
"""Mini Linux Shell desktop -- Python standard library + Tkinter, Linux only."""
import argparse
import os
from pathlib import Path
import re
import sys

try:
    import tkinter as tk
    from tkinter import messagebox, ttk
except ImportError:
    raise SystemExit("Tkinter is missing. On Ubuntu: sudo apt install python3-tk")

from ui_backend import ShellSession

BG = "#0c1119"
PANEL = "#141c28"
EDGE = "#273345"
TEXT = "#e8edf5"
MUTED = "#96a6bb"
MINT = "#88edca"
ORANGE = "#ffb88a"
TERMINAL = "#080d14"
FONT = "DejaVu Sans"
MONO = "DejaVu Sans Mono"


class ShellUI:
    def __init__(self, root):
        self.root = root
        root.title("Mini Linux Shell")
        root.geometry("1200x800")
        root.minsize(960, 680)
        root.configure(bg=BG)
        self.history = []
        self.history_index = 0
        self.closing = False
        self.last_state = None
        self.command_buttons = []
        self._build()
        self.session = ShellSession()
        root.protocol("WM_DELETE_WINDOW", self.close)
        root.bind("<Control-l>", lambda _: self.clear())
        self.entry.bind("<Return>", lambda _: self.submit())
        self.entry.bind("<Up>", lambda _: self.recall(-1))
        self.entry.bind("<Down>", lambda _: self.recall(1))
        self.entry.bind("<Control-c>", lambda _: self.control(b"\x03"))
        self.entry.bind("<Control-z>", lambda _: self.control(b"\x1a"))
        self.entry.bind("<Control-d>", lambda _: self.control(b"\x04"))
        self.terminal.bind("<Configure>", self.resize_terminal)
        self.entry.focus_set()
        self.tick()

    def label(self, parent, text, size=10, color=TEXT, bold=False, **kw):
        return tk.Label(parent, text=text, bg=parent.cget("bg"), fg=color,
                        font=(FONT, size, "bold" if bold else "normal"), **kw)

    def button(self, parent, text, command, accent=False, shell_command=False):
        b = tk.Button(parent, text=text, command=command, relief="flat", bd=0,
                      bg=MINT if accent else EDGE, fg=BG if accent else TEXT,
                      activebackground="#b4f9df" if accent else "#35455c",
                      activeforeground=BG if accent else TEXT,
                      disabledforeground="#607085", cursor="hand2",
                      font=(FONT, 10, "bold"), padx=13, pady=9)
        if shell_command:
            self.command_buttons.append(b)
        return b

    def _build(self):
        header = tk.Frame(self.root, bg=BG)
        header.pack(fill="x", padx=26, pady=(22, 14))
        title = tk.Frame(header, bg=BG)
        title.pack(side="left")
        self.label(title, "Mini Linux Shell", 25, TEXT, True).pack(anchor="w", pady=(3, 0))
        self.label(title, "Execute commands and manage background jobs.",
                   10, MUTED).pack(anchor="w", pady=(3, 0))
        badge = tk.Frame(header, bg=PANEL, padx=15, pady=12)
        badge.pack(side="right")
        self.label(badge, "LOCAL SESSION", 11, MINT, True).pack(anchor="w")
        self.pid_label = self.label(badge, "Connecting to shell…", 9, MUTED)
        self.pid_label.pack(anchor="w", pady=(4, 0))

        stats = tk.Frame(self.root, bg=BG)
        stats.pack(fill="x", padx=26, pady=(0, 16))
        self.stat_values = {}
        for index, (key, name, color) in enumerate([
            ("running", "RUNNING JOBS", MINT), ("stopped", "STOPPED JOBS", ORANGE),
            ("done", "COMPLETED IN TABLE", TEXT), ("mode", "TERMINAL OWNER", MINT)
        ]):
            stats.columnconfigure(index, weight=1, uniform="stats")
            card = tk.Frame(stats, bg=PANEL, padx=16, pady=12)
            card.grid(row=0, column=index, sticky="nsew", padx=(0, 10 if index < 3 else 0))
            self.label(card, name, 8, MUTED, True).pack(anchor="w")
            value = self.label(card, "Shell" if key == "mode" else "0", 20, color, True)
            value.pack(anchor="w", pady=(5, 0))
            self.stat_values[key] = value

        body = tk.PanedWindow(self.root, orient="horizontal", bg=BG,
                              sashwidth=12, bd=0, relief="flat")
        body.pack(fill="both", expand=True, padx=26)
        console = tk.Frame(body, bg=PANEL, padx=15, pady=14)
        sidebar = tk.Frame(body, bg=PANEL, padx=15, pady=14)
        body.add(console, minsize=480, stretch="always")
        body.add(sidebar, minsize=325, width=365, stretch="never")

        bar = tk.Frame(console, bg=PANEL)
        bar.pack(fill="x", pady=(0, 10))
        self.label(bar, "LIVE TERMINAL", 10, MINT, True).pack(side="left")
        self.button(bar, "Clear view", self.clear).pack(side="right")
        terminal_frame = tk.Frame(console, bg=TERMINAL)
        terminal_frame.pack(fill="both", expand=True)
        self.terminal = tk.Text(terminal_frame, bg=TERMINAL, fg=TEXT, insertbackground=MINT,
                                selectbackground="#304760", relief="flat", bd=0,
                                font=(MONO, 11), wrap="char", padx=14, pady=13,
                                state="disabled", height=16, width=60)
        scroll = ttk.Scrollbar(terminal_frame, command=self.terminal.yview)
        self.terminal.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        self.terminal.pack(side="left", fill="both", expand=True)
        self.terminal.tag_configure("notice", foreground=MINT)
        self.terminal.tag_configure("error", foreground=ORANGE)
        self.write("Welcome to your process workspace.\n"
                   "Try: sleep 30 &   then select the job in the panel.\n\n", "notice")

        self.context_label = self.label(console, "READY  /  Enter a Linux command", 9, MUTED)
        self.context_label.pack(anchor="w", pady=(12, 6))
        input_frame = tk.Frame(console, bg=EDGE, padx=2, pady=2)
        input_frame.pack(fill="x")
        self.label(input_frame, "  >", 14, MINT, True).pack(side="left")
        self.entry = tk.Entry(input_frame, bg=PANEL, fg=TEXT, insertbackground=MINT,
                              relief="flat", bd=0, font=(MONO, 11))
        self.entry.pack(side="left", fill="x", expand=True, ipady=12, padx=8)
        self.run_button = self.button(input_frame, "Run / Send", self.submit, True)
        self.run_button.pack(side="right")
        controls = tk.Frame(console, bg=PANEL)
        controls.pack(fill="x", pady=(9, 0))
        self.button(controls, "Interrupt  ^C", lambda: self.control(b"\x03")).pack(side="left", padx=(0, 6))
        self.button(controls, "Stop  ^Z", lambda: self.control(b"\x1a")).pack(side="left", padx=(0, 6))
        self.button(controls, "End input  ^D", lambda: self.control(b"\x04")).pack(side="left")

        self.label(sidebar, "PROCESS EXPLORER", 10, MINT, True).pack(anchor="w")
        self.label(sidebar, "Actual child processes · latest 32 jobs", 9, MUTED).pack(anchor="w", pady=(5, 11))
        style = ttk.Style(self.root)
        style.theme_use("clam")
        style.configure("Jobs.Treeview", background=PANEL, foreground=TEXT,
                        fieldbackground=PANEL, borderwidth=0, rowheight=32,
                        font=(FONT, 9))
        style.configure("Jobs.Treeview.Heading", background=EDGE, foreground=MUTED,
                        relief="flat", font=(FONT, 9, "bold"))
        style.map("Jobs.Treeview", background=[("selected", "#304760")],
                  foreground=[("selected", TEXT)])
        columns = ("id", "pid", "state", "command")
        self.tree = ttk.Treeview(sidebar, columns=columns, show="headings",
                                 style="Jobs.Treeview", selectmode="browse", height=6)
        for col, name, width in [("id", "Job", 35), ("pid", "PID", 64),
                                  ("state", "State", 65), ("command", "Command", 140)]:
            self.tree.heading(col, text=name)
            self.tree.column(col, width=width, minwidth=width, stretch=col == "command")
        self.tree.tag_configure("Running", foreground=MINT)
        self.tree.tag_configure("Stopped", foreground=ORANGE)
        self.tree.tag_configure("Done", foreground=MUTED)
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self.select_job)
        self.selection_label = self.label(sidebar, "Select an active job to control it.", 9, MUTED,
                                          anchor="w", justify="left", wraplength=310)
        self.selection_label.pack(fill="x", pady=(10, 8))
        actions = tk.Frame(sidebar, bg=PANEL)
        actions.pack(fill="x")
        for name, action in [("Foreground", "fg"), ("Resume", "bg"), ("Terminate", "kill")]:
            self.button(actions, name, lambda a=action: self.job_action(a),
                        shell_command=True).pack(side="left", padx=(0, 5))

        tk.Frame(sidebar, bg=EDGE, height=1).pack(fill="x", pady=17)
        self.label(sidebar, "QUICK COMMANDS", 9, MUTED, True).pack(anchor="w", pady=(0, 8))
        quick = tk.Frame(sidebar, bg=PANEL)
        quick.pack(fill="x")
        for index, command in enumerate(["pwd", "ls", "jobs", "sleep 30 &", "help"]):
            b = self.button(quick, command, lambda c=command: self.send_command(c), shell_command=True)
            b.grid(row=index // 2, column=index % 2, sticky="ew", padx=(0, 6), pady=(0, 6))
        quick.columnconfigure(0, weight=1)
        quick.columnconfigure(1, weight=1)
        tk.Frame(sidebar, bg=EDGE, height=1).pack(fill="x", pady=(12, 13))
        self.label(sidebar, "COMMAND GUIDE", 9, MUTED, True).pack(anchor="w")
        self.label(sidebar, "command &   Run in the background\n"
                   "jobs               List background jobs\n"
                   "kill %ID          Terminate a job\n"
                   "help               Show all commands", 9, TEXT,
                   justify="left", anchor="w").pack(fill="x", pady=(7, 0))
        footer = tk.Frame(self.root, bg=BG)
        footer.pack(fill="x", padx=26, pady=12)
        self.cwd_label = self.label(footer, "Working directory", 9, MUTED, anchor="w")
        self.cwd_label.pack(side="left", fill="x", expand=True)
        self.label(footer, "↑ ↓ history  ·  Ctrl+L clear  ·  Line-oriented terminal", 9, MUTED).pack(side="right")

    def write(self, text, tag=None):
        # TERM=dumb avoids most escape output. Strip CSI sequences from tools
        # that emit them anyway; this widget is not a full terminal emulator.
        text = re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", text).replace("\r", "")
        self.terminal.configure(state="normal")
        self.terminal.insert("end", text, (tag,) if tag else ())
        if int(self.terminal.index("end-1c").split(".")[0]) > 4000:
            self.terminal.delete("1.0", "1000.0")
        self.terminal.see("end")
        self.terminal.configure(state="disabled")

    def clear(self):
        self.terminal.configure(state="normal")
        self.terminal.delete("1.0", "end")
        self.terminal.configure(state="disabled")
        return "break"

    def submit(self):
        text = self.entry.get()
        if len(text.encode("utf-8")) > 3000:
            self.write("\nInput too long for the desktop terminal (3000-byte limit).\n", "error")
            return "break"
        try:
            self.session.send(text)
        except OSError as exc:
            self.write("\n" + str(exc) + "\n", "error")
            return "break"
        if text and (not self.history or self.history[-1] != text):
            self.history.append(text)
        self.history_index = len(self.history)
        self.entry.delete(0, "end")
        self.entry.focus_set()
        return "break"

    def send_command(self, command):
        self.session.read_state()
        if self.session.state.get("foreground"):
            self.write("\nStop or interrupt the foreground job before using shell controls.\n", "notice")
            return
        self.entry.delete(0, "end")
        self.entry.insert(0, command)
        self.submit()

    def control(self, data):
        try:
            self.session.send_bytes(data)
        except OSError as exc:
            self.write("\n" + str(exc) + "\n", "error")
        self.entry.focus_set()
        return "break"

    def recall(self, direction):
        self.history_index = max(0, min(len(self.history), self.history_index + direction))
        text = self.history[self.history_index] if self.history_index < len(self.history) else ""
        self.entry.delete(0, "end")
        self.entry.insert(0, text)
        return "break"

    def select_job(self, _event=None):
        selected = self.tree.selection()
        if selected:
            job = next((j for j in self.session.state["jobs"] if str(j["id"]) == selected[0]), None)
            if job:
                self.selection_label.configure(text=f"Job %{job['id']} · {job['state']} · {job['command']}")

    def job_action(self, action):
        selected = self.tree.selection()
        if not selected:
            self.selection_label.configure(text="Select a job in the table first.")
            return
        self.session.read_state()
        job = next((j for j in self.session.state["jobs"] if str(j["id"]) == selected[0]), None)
        if not job or job["state"] == "Done":
            self.selection_label.configure(text="That job has finished. Select an active job.")
            return
        if action == "bg" and job["state"] != "Stopped":
            self.selection_label.configure(text="Resume applies to stopped jobs.")
            return
        self.send_command(f"{action} %{job['id']}")

    def update_state(self):
        state = self.session.state
        if state == self.last_state:
            return
        self.last_state = state
        jobs = state["jobs"]
        for key, name in [("running", "Running"), ("stopped", "Stopped"), ("done", "Done")]:
            self.stat_values[key].configure(text=str(sum(j["state"] == name for j in jobs)))
        owner = state.get("foreground", 0)
        self.stat_values["mode"].configure(text=f"PID {owner}" if owner else "Shell")
        self.pid_label.configure(text=f"Shell PID {state['shell_pid']} · local session")
        self.context_label.configure(text="PROCESS INPUT  /  Send text or use Interrupt / Stop" if owner
                                      else "READY  /  Enter a Linux command")
        self.cwd_label.configure(text="Directory: " + state.get("cwd", ""))
        for b in self.command_buttons:
            b.configure(state="disabled" if owner else "normal")
        existing = set(self.tree.get_children())
        for j in sorted(jobs, key=lambda item: item["id"], reverse=True):
            iid = str(j["id"])
            values = (f"%{iid}", j["pid"], j["state"], j["command"])
            if iid in existing:
                self.tree.item(iid, values=values, tags=(j["state"],))
                existing.remove(iid)
            else:
                self.tree.insert("", 0, iid=iid, values=values, tags=(j["state"],))
        for iid in existing:
            self.tree.delete(iid)
        self.select_job()

    def resize_terminal(self, event):
        if hasattr(self, "session"):
            self.session.resize(max(40, (event.width - 28) // 9), max(8, (event.height - 26) // 19))

    def tick(self):
        if self.closing:
            return
        output = self.session.read_output()
        if output:
            self.write(output)
        self.session.read_state()
        self.update_state()
        if self.session.check_exit():
            trailing = self.session.read_output()
            if trailing:
                self.write(trailing)
            self.entry.configure(state="disabled")
            self.run_button.configure(state="disabled")
            for button in self.command_buttons:
                button.configure(state="disabled")
            self.context_label.configure(text="SESSION ENDED  /  Close this window to finish")
            return
        self.root.after(35, self.tick)

    def close(self):
        if self.closing:
            return
        self.closing = True
        self.session.request_close()
        self.context_label.configure(text="CLOSING  /  Cleaning up tracked jobs…")
        self._finish_close(0)

    def _finish_close(self, attempts):
        self.session.read_output()
        if self.session.check_exit():
            self.session.close_handles()
            self.root.destroy()
            return
        # The C shell performs bounded cleanup of its own process groups.
        if attempts == 40:
            self.context_label.configure(text="Waiting for the operating system to release the shell…")
        self.root.after(50, lambda: self._finish_close(attempts + 1))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--smoke-test", action="store_true", help="open, exercise and close the UI")
    args = parser.parse_args()
    if not sys.platform.startswith("linux"):
        raise SystemExit("Run this project on Linux or inside Ubuntu on WSL.")
    os.chdir(Path(__file__).resolve().parent)
    try:
        root = tk.Tk()
    except tk.TclError as exc:
        raise SystemExit("A Linux graphical desktop is required. Use Ubuntu desktop or WSLg.\n" + str(exc))
    try:
        app = ShellUI(root)
    except (OSError, tk.TclError) as exc:
        messagebox.showerror("Mini Linux Shell", str(exc), parent=root)
        root.destroy()
        return 1
    if args.smoke_test:
        root.after(200, lambda: app.send_command("sleep 30 &"))
        root.after(500, lambda: app.send_command("pwd"))
        root.after(900, app.close)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
