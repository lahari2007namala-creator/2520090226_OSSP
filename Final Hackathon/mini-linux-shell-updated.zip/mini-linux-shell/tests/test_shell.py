#!/usr/bin/env python3
"""Integration tests use a real controlling PTY and real child processes."""
import os
from pathlib import Path
import sys
import time
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from ui_backend import ShellSession


class ShellTests(unittest.TestCase):
    def setUp(self):
        self.shell = ShellSession()
        self.output = ""
        self.wait_for(lambda: "mini-shell> " in self.output)

    def pump(self):
        self.output += self.shell.read_output()
        self.shell.read_state()
        self.shell.check_exit()

    def wait_for(self, predicate, timeout=4):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            self.pump()
            if predicate():
                return
            time.sleep(0.01)
        self.fail("Timed out. Output:\n" + self.output[-5000:])

    def run_command(self, command):
        self.output = ""
        self.shell.send(command)
        self.wait_for(lambda: "mini-shell> " in self.output)
        return self.output

    def job(self, job_id):
        return next((j for j in self.shell.state["jobs"] if j["id"] == job_id), None)

    def start_background(self, command="sleep 30 &"):
        self.run_command(command)
        self.wait_for(lambda: any(j["state"] == "Running" and j["background"]
                                  for j in self.shell.state["jobs"]))
        return max((j for j in self.shell.state["jobs"] if j["background"]), key=lambda j: j["id"])

    def tearDown(self):
        self.shell.request_close()
        deadline = time.monotonic() + 4
        while self.shell.alive and time.monotonic() < deadline:
            self.pump()
            time.sleep(0.01)
        self.assertFalse(self.shell.alive, "Shell cleanup did not finish")
        self.shell.close_handles()

    def test_external_command_and_quotes(self):
        out = self.run_command("printf '%s\\n' 'hello world'")
        self.assertIn("\r\nhello world\r\n", out)
        self.assertIn("&", self.run_command("printf '%s\\n' '&'"))
        self.assertIn("\r\nhello again\r\n", self.run_command('printf "%s\\n" "hello again"'))

    def test_directory_changes_persist_in_parent(self):
        self.run_command("cd /tmp")
        self.assertIn("\r\n/tmp\r\n", self.run_command("pwd"))
        self.assertEqual(self.shell.state["cwd"], "/tmp")
        self.assertIn("No such file", self.run_command("cd /not/a/real/directory"))

    def test_background_job_keeps_shell_responsive(self):
        start = time.monotonic()
        j = self.start_background()
        out = self.run_command("echo responsive")
        self.assertIn("\r\nresponsive\r\n", out)
        self.assertLess(time.monotonic() - start, 2)
        self.assertEqual(self.job(j["id"])["state"], "Running")
        self.assertIn("sleep 30 &", self.run_command("jobs"))

    def test_completed_background_job_is_reaped_without_input(self):
        j = self.start_background("sleep 0.2 &")
        self.wait_for(lambda: self.job(j["id"])["state"] == "Done")
        self.assertFalse(Path(f"/proc/{j['pid']}").exists(), "Child was not reaped")

    def test_foreground_transfer_and_ctrl_c(self):
        j = self.start_background()
        self.shell.send(f"fg %{j['id']}")
        self.wait_for(lambda: self.shell.state["foreground"] == j["pid"])
        self.assertEqual(os.tcgetpgrp(self.shell.master), j["pid"])
        self.shell.send_bytes(b"\x03")
        self.wait_for(lambda: self.job(j["id"])["state"] == "Done" and not self.shell.state["foreground"])
        self.assertEqual(self.job(j["id"])["result"], 130)
        self.assertEqual(os.tcgetpgrp(self.shell.master), self.shell.pid)
        self.assertIn("still-alive", self.run_command("echo still-alive"))

    def test_ctrl_z_bg_and_resume_foreground(self):
        self.shell.send("sleep 30")
        self.wait_for(lambda: bool(self.shell.state["foreground"]))
        j = self.shell.state["jobs"][-1]
        self.shell.send_bytes(b"\x1a")
        self.wait_for(lambda: self.job(j["id"])["state"] == "Stopped" and not self.shell.state["foreground"])
        self.run_command(f"bg %{j['id']}")
        self.wait_for(lambda: self.job(j["id"])["state"] == "Running")
        self.run_command(f"kill -STOP %{j['id']}")
        self.wait_for(lambda: self.job(j["id"])["state"] == "Stopped")
        self.shell.send(f"fg %{j['id']}")
        self.wait_for(lambda: self.shell.state["foreground"] == j["pid"] and self.job(j["id"])["state"] == "Running")
        self.shell.send_bytes(b"\x03")
        self.wait_for(lambda: self.job(j["id"])["state"] == "Done")

    def test_terminate_a_stopped_job(self):
        j = self.start_background()
        self.run_command(f"kill -STOP %{j['id']}")
        self.wait_for(lambda: self.job(j["id"])["state"] == "Stopped")
        self.run_command(f"kill %{j['id']}")
        self.wait_for(lambda: self.job(j["id"])["state"] == "Done")
        self.assertEqual(self.job(j["id"])["result"], 143)

    def test_background_terminal_reader_stops_until_foreground(self):
        self.run_command("cat &")
        self.wait_for(lambda: any(j["command"] == "cat &" and j["state"] == "Stopped"
                                  for j in self.shell.state["jobs"]))
        j = next(j for j in self.shell.state["jobs"] if j["command"] == "cat &")
        self.shell.send(f"fg %{j['id']}")
        self.wait_for(lambda: self.shell.state["foreground"] == j["pid"])
        self.output = ""
        self.shell.send("hello-cat")
        self.wait_for(lambda: self.output.count("hello-cat") >= 2)
        self.shell.send_bytes(b"\x04")
        self.wait_for(lambda: self.job(j["id"])["state"] == "Done")
        self.assertTrue(self.shell.alive)

    def test_errors_do_not_crash_shell(self):
        for command, expected in [
            ("no_such_command_123", "No such file"),
            ("echo 'unfinished", "Unclosed quote"),
            ("ls | wc", "not supported"),
            ("sleep 1 && pwd", "Syntax"),
            ("kill %0", "Invalid job ID"),
            ("kill %-1", "Invalid job ID"),
            ("fg %999999", "No active job"),
            ("jobs &", "do not accept"),
        ]:
            with self.subTest(command=command):
                self.assertIn(expected, self.run_command(command))
        self.assertIn("survived", self.run_command("echo survived"))

    def test_exit_cleans_running_stopped_and_hup_ignoring_jobs(self):
        one = self.start_background()
        two = self.start_background()
        self.run_command(f"kill -STOP %{two['id']}")
        self.wait_for(lambda: self.job(two["id"])["state"] == "Stopped")
        self.output = ""
        self.shell.send("python3 -c 'import signal,time; signal.signal(signal.SIGHUP,signal.SIG_IGN); print(\"HUP-READY\",flush=True); time.sleep(30)' &")
        self.wait_for(lambda: "HUP-READY\r\n" in self.output)
        self.shell.read_state()
        active = [j["pid"] for j in self.shell.state["jobs"] if j["state"] != "Done"]
        self.assertEqual(len(active), 3)
        self.shell.send("exit")
        self.wait_for(lambda: not self.shell.alive)
        self.assertFalse(Path(f"/proc/{one['pid']}").exists())
        for pid in active:
            self.assertFalse(Path(f"/proc/{pid}").exists(), f"Child {pid} survived exit")


if __name__ == "__main__":
    unittest.main(verbosity=2)
