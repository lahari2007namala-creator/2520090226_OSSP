# Live demonstration and preparation

## Start

In the regular Ubuntu terminal:

```bash
make
make test
python3 gui.py
```

## Suggested 4-minute demonstration

1. Explain: "The desktop is our interface. The C program performs process
   management using Linux APIs."
2. Run `pwd` and `ls`. Point to the directory footer and actual child PID.
3. Run `sleep 30 &`. Point out its Running state and job ID.
4. Run `echo shell-is-responsive`. Both operations coexist; the prompt is free.
5. Run `jobs` and compare it with the process panel.
6. Select the sleep job and choose **Foreground**. The owner changes to that PID.
7. Choose **Stop ^Z**. The state changes to Stopped; terminal ownership returns
   to the shell. Explain SIGTSTP and process groups.
8. Select the stopped job and choose **Resume**. It runs in the background.
9. Select it and choose **Terminate**. It receives SIGTERM and becomes Done.
10. Run `sleep 2 &`. Wait without entering input. Show its automatic completion.
    Explain SIGCHLD, waitpid and prevention of zombie children.
11. Run an invalid command such as `not_a_command`. The shell reports an error
    and remains usable.
12. Run `sleep 30 &`, then `exit`. Explain cleanup of active tracked jobs.

Job IDs are allocated for every external command. Always use the ID displayed
by the application instead of memorizing `%1`.

## Viva questions

**What is the difference between a program and a process?** A program is code;
a process is a running instance with identity, state and OS-managed resources.

**What happens after fork?** Parent and child continue from the fork call.
The return value distinguishes them: child gets zero; parent gets the child PID.

**What does execvp do?** It replaces the child process image with the requested
program, with the same PID. It returns only if execution fails.

**Why is cd a built-in?** The parent shell must change its own directory.
A directory change in a child would not change the parent's directory.

**Does background mean lower CPU priority?** No. It means the shell does not
wait at the prompt and the job does not own terminal input. Kernel scheduling
still determines CPU execution.

**What is a zombie?** A terminated child whose parent has not yet collected its
exit status. waitpid reaps it.

**What is a process group?** A collection of related processes addressed as a
group for signals and terminal control. This prototype launches one command
per job group.

**Can the GUI terminate any system process?** Its job controls signal active
jobs tracked by this shell. They do not accept arbitrary process IDs.

**Is the desktop a full terminal emulator?** No. It is a line-oriented display
connected to a real PTY. Full-screen/cursor-addressing programs are outside
the desktop view's scope.

## Before a demonstration

- Build and run the project on the computer you will use.
- Read the C code and trace one foreground and one background execution.
- Run the automated checks and record your own results.
- Verify the setup instructions from a fresh copy.
