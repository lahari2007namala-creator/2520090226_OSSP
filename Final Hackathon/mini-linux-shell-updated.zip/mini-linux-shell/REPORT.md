# Mini Linux Shell with Background Job Management

## Abstract

The project implements a small Linux command interpreter in C, with an optional
desktop interface in Python/Tkinter. Users execute foreground and background
commands, inspect child-process states, stop/resume jobs, and send termination
signals. The implementation demonstrates POSIX process creation, program
execution, process groups, terminal ownership, signal delivery and child reaping.
The interface obtains real status from the C job table rather than generating
simulated process results.

## Problem statement

Develop a mini Linux shell with background job management. The system must
execute user commands while allowing selected jobs to continue independently
of the prompt, and provide meaningful control and visibility over those jobs.

## Objectives

1. Read and parse command lines and arguments.
2. Execute external programs through fork/exec.
3. Support foreground and background execution.
4. Maintain an identifiable job table.
5. Implement jobs, fg, bg and job-specific signal delivery.
6. Protect the shell from terminal interrupts intended for child jobs.
7. Reap children promptly and clean up tracked jobs at normal shutdown.
8. Provide a desktop interface suitable for a live demonstration.

## Operating-system concepts

| Concept | Implementation |
| --- | --- |
| Parent/child process relationship | Shell calls fork; child calls execvp |
| Process identity | Child PID is the process-group ID for its job |
| Foreground execution | Terminal belongs to the job group while the shell waits |
| Background execution | Shell retains terminal ownership and accepts new input |
| Concurrency | Kernel schedules the shell and child processes |
| Signals | INT, TSTP, CHLD, TERM, STOP, CONT and shutdown HUP/KILL |
| Synchronization | Parent waits for foreground completion/stopping |
| Zombie prevention | waitpid consumes each direct child's state and termination status |
| File-system state | cd changes the parent shell's working directory |
| Interprocess communication | PTY for terminal I/O, self-pipe for wakeups, Unix datagrams for UI state |

## System design

There are three layers. The GUI provides a command entry, output view and jobs
panel. The PTY transport gives the C shell a real controlling terminal. The C
core owns parsing, job records, process creation, signal policy and cleanup.
Linux enforces process-group terminal access and schedules runnable processes.

The desktop status channel is private and local. It receives snapshots of the
C job table; commands are not executed by Python's shell or a network service.

## Execution algorithm

1. Initialize process group, terminal settings, signal handlers and self-pipe.
2. Wait for command input or a child-state notification using poll.
3. Read one command line without prefetching input intended for children.
4. Parse quoting, escaping and an optional final ampersand.
5. Execute built-ins in the parent when applicable.
6. Allocate a job-table slot and fork an external-command child.
7. Establish the child's process group in both parent and child.
8. Restore default signal dispositions in the child.
9. For a foreground job, transfer terminal ownership before releasing the child.
10. Child executes the requested program using execvp.
11. For a background job, return immediately to the command prompt.
12. Reap state changes with waitpid; publish updated state to the UI.
13. Restore shell terminal ownership when the foreground job stops or exits.
14. Repeat until exit or shutdown is requested.

## Data structure

A fixed-size table contains 32 job records. Each record stores job ID, PID/PGID,
running/stopped/done state, foreground/background mode, status code, command
text, and saved terminal modes where required. Completed slots can be reused;
active jobs are never evicted to make room for another command.

Lookup and reaping updates scan this small table. This is adequate for the
bounded teaching prototype; larger shells can use indexed structures and
multi-process job records. It is not a CPU scheduling algorithm.

## Signal handling and correctness

Handlers set sig_atomic_t flags and write a wakeup byte. Allocation, formatted
output, UI publication and child reaping happen in normal event-loop code.
This avoids unsafe work inside signal handlers. A full self-pipe is harmless
because it is already readable and therefore already wakes poll.

Foreground jobs receive a separate process group and terminal ownership. The
shell ignores terminal stop signals that would otherwise stop it during job
control. Children restore default signal actions before exec. A launch gate
prevents a new child from reading the terminal before ownership is transferred.

A stopped foreground job can be resumed in the background or restored to the
foreground, including its saved terminal settings. A background job that reads
the terminal can legitimately stop with SIGTTIN.

## Technologies

- C11 and Linux/POSIX process/terminal APIs.
- GCC and make for compilation.
- Python standard library: tkinter/ttk, pty, socket, os, fcntl, termios and json.
- A real graphical Linux desktop or WSLg for the desktop window.
- Python unittest for process-level integration tests.

## Testing and results

See TESTING.md and run `make test` to reproduce the checks. Tests execute real
processes in a controlling PTY, verify terminal ownership, exercise stop/resume
and termination, and check that terminated direct children disappear from
`/proc`. GUI checks are recorded separately from core/transport checks.

No throughput or performance claim is made from these functional tests.
Counters show current job-table contents, not kernel-wide process counts.

## Limitations

One directly launched external program per job; no pipelines, redirection,
compound shell syntax, substitutions, wildcard expansion or shell scripts.
The desktop text view supports line-oriented programs rather than full terminal
emulation. The job table is bounded. Daemonization and independently escaping
descendants are outside the cleanup contract. SIGKILL prevents application
cleanup, as with other userspace programs.

## Impact and future work

The prototype makes normally hidden OS mechanisms visible through real PIDs,
state transitions and terminal ownership. It supports learning and controlled
demonstrations of process management. Extensions include pipelines, I/O
redirection, persistent history, a full terminal emulator, and multi-process jobs.

