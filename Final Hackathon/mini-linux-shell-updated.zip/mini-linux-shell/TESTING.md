# Testing and validation

Validation date: 17 October 2026.

## Reproduce the automated checks

```bash
make
make test
```

The integration suite uses real child processes and a controlling PTY through
the same transport used by the GUI. It does not mock process state.

| Scenario | Observed result |
| --- | --- |
| External commands, quoted arguments and a literal ampersand | Passed |
| Parent-shell directory change and missing directory error | Passed |
| Background sleep plus a responsive subsequent command | Passed |
| Background completion without more user input; child reaped from /proc | Passed |
| fg terminal ownership, Ctrl+C, result 130, shell ownership restored | Passed |
| Ctrl+Z stop, bg resume, explicit STOP, fg resume | Passed |
| SIGTERM of a stopped job, continuation for delivery, result 143 | Passed |
| Background cat receives SIGTTIN; fg allows input; Ctrl+D completes cat | Passed |
| Missing executable, syntax errors, invalid IDs and unsupported operators | Passed |
| Exit cleanup of running, stopped and SIGHUP-ignoring children | Passed |

Recorded automated result: **10 tests passed**. GCC completed with
`-std=c11 -Wall -Wextra -Wpedantic -O2` and no compiler warnings. Python files
also passed bytecode compilation checks.

## GUI validation

The desktop smoke test passed on 17 October 2026 under a virtual X display:
the window opened, submitted `sleep 30 &` and `pwd`, and closed with cleanup.
The process exited with status 0 and no Python/Tk callback errors.

The GUI requires Tkinter and a working graphical display. The backend is
covered by the PTY tests above. Use the following to exercise opening the
window, submitting a background job and pwd, and cleanup on close:

```bash
python3 gui.py --smoke-test
```

On a Linux test machine with Xvfb installed, the same smoke test can run with:

```bash
xvfb-run -a python3 gui.py --smoke-test
```

For a local demonstration, run the normal UI on your desktop and follow DEMO.md.
Check that text is readable, a sleep job appears, selecting a job enables the
expected action, Stop changes its state, Resume continues it, Terminate ends
it, and the window closes after cleaning up active tracked jobs.

## Scope of the evidence

Functional tests cover the stated command and process-control behaviours on
Linux. They are not performance benchmarks, full POSIX-shell conformance
tests, or a guarantee for arbitrary daemonizing programs. The desktop text
view deliberately supports line-oriented output instead of full terminal
emulation. Record your own screenshots and any laptop-specific issues before
submission.
