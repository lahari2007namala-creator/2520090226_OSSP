"""PTY transport for the desktop UI; command execution remains in C."""
import codecs
import errno
import fcntl
import json
import os
from pathlib import Path
import pty
import signal
import socket
import struct
import termios


class ShellSession:
    def __init__(self, executable=None):
        executable = Path(executable or Path(__file__).with_name("mini_shell")).resolve()
        if not executable.is_file():
            raise FileNotFoundError("Build the C shell first: make")
        reader, writer = socket.socketpair(socket.AF_UNIX, socket.SOCK_DGRAM)
        reader.setblocking(False)
        writer.set_inheritable(True)
        pid, master = pty.fork()
        if pid == 0:
            reader.close()
            env = os.environ.copy()
            env["MINISHELL_STATUS_FD"] = str(writer.fileno())
            env["TERM"] = "dumb"  # The UI displays line-oriented output.
            try:
                os.execve(str(executable), [str(executable)], env)
            except OSError as exc:
                os.write(2, (str(exc) + "\n").encode())
                os._exit(126)
        writer.close()
        self.pid = pid
        self.master = master
        self.channel = reader
        self.alive = True
        self.output_open = True
        self.closed = False
        self.state = {"shell_pid": pid, "foreground": 0, "cwd": str(Path.cwd()), "jobs": []}
        self.decoder = codecs.getincrementaldecoder("utf-8")("replace")
        os.set_blocking(master, False)
        self.resize(100, 30)

    def resize(self, columns, rows):
        if self.closed:
            return
        try:
            fcntl.ioctl(self.master, termios.TIOCSWINSZ,
                        struct.pack("HHHH", max(5, rows), max(20, columns), 0, 0))
        except OSError:
            pass

    def send(self, text):
        self.send_bytes((text + "\n").encode("utf-8"))

    def send_bytes(self, data):
        if self.closed or not self.alive:
            return
        try:
            written = os.write(self.master, data)
            if written != len(data):
                raise OSError("Terminal input is busy; send a shorter line.")
        except BlockingIOError as exc:
            raise OSError("Terminal input is busy; try again.") from exc

    def read_output(self):
        if self.closed or not self.output_open:
            return ""
        chunks = []
        # Bounded work keeps the Tk event loop responsive under heavy output.
        for _ in range(32):
            try:
                data = os.read(self.master, 8192)
                if not data:
                    self.output_open = False
                    break
                chunks.append(self.decoder.decode(data))
            except BlockingIOError:
                break
            except OSError as exc:
                if exc.errno == errno.EIO:
                    self.output_open = False
                    break
                raise
        return "".join(chunks)

    def read_state(self):
        changed = False
        if self.closed:
            return changed
        while True:
            try:
                packet = self.channel.recv(65536)
                if not packet:
                    break
                state = json.loads(packet)
                if isinstance(state, dict) and "jobs" in state:
                    self.state = state
                    changed = True
            except BlockingIOError:
                break
            except (ValueError, OSError):
                break
        return changed

    def check_exit(self):
        if self.alive:
            try:
                pid, _ = os.waitpid(self.pid, os.WNOHANG)
                if pid:
                    self.alive = False
            except ChildProcessError:
                self.alive = False
        return not self.alive

    def request_close(self):
        if self.alive:
            try:
                os.kill(self.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass

    def close_handles(self):
        if not self.closed:
            os.close(self.master)
            self.channel.close()
            self.closed = True
